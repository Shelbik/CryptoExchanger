public class TradePosition {

    private Account account;
    private Datum datum;

    public TradePosition(Account account, Datum datum) {
        this.account = account;
        this.datum = datum;
    }

    public boolean openShortPosition(int amount, int leverage, double awaitingPrice, Crypto crypto) { // leverage - кредитное плечо
        if (this.account.getBalance() < amount) {
            return false;
        }

        GeneratingCryptoPrice generatingCryptoPrice = new GeneratingCryptoPrice(this.datum);
        generatingCryptoPrice.generateNewPrice();
        // pocet peniaze na ktore si bude kupovat coin ked oni padnu v cene
        double moneyForOperation = amount * leverage;
        // kolko si coins si pozicial od kryptomen obhcodu
        double loandedCoinAmount = (amount * leverage) / generatingCryptoPrice.getActualCoinPrice(crypto);

        if (awaitingPrice < generatingCryptoPrice.getActualCoinPrice(crypto)) {
            double alreadyReturnCoin = moneyForOperation / awaitingPrice;
            if (alreadyReturnCoin >= loandedCoinAmount) {
                double profit = ((alreadyReturnCoin - loandedCoinAmount) * awaitingPrice) - moneyForOperation;
                this.account.deposit(profit);
                return true;
            }
        } else if (awaitingPrice > generatingCryptoPrice.getActualCoinPrice(crypto)) {
            if (this.account.getBalance() >= amount * leverage) {
                this.account.withdrawal(amount * leverage);
            } else {
                // ak nema tolko peniaze aby vratil co pozicial tak sa zobereme jemu vsetko co ma
                this.account.withdrawal(this.account.getBalance());
            }
            return false;
        }
        return false;
    }



    public boolean openLongPosition(int amount, int leverage, double awaitingPrice, Crypto crypto) { // leverage - кредитное плечо
        if (this.account.getBalance() < amount) {
            return false;
        }

        GeneratingCryptoPrice generatingCryptoPrice = new GeneratingCryptoPrice(this.datum);
        generatingCryptoPrice.generateNewPrice();
        // pocet peniaze na ktore si bude kupovat coin ked oni padnu v cene
        double moneyForOperation = amount * leverage;
        // kolko si coins si pozicial od kryptomen obhcodu
        double loandedCoinAmount = (amount * leverage) / generatingCryptoPrice.getActualCoinPrice(crypto);

        if (awaitingPrice > generatingCryptoPrice.getActualCoinPrice(crypto)) {
            double alreadyReturnCoin = moneyForOperation / awaitingPrice;
            if (alreadyReturnCoin >= loandedCoinAmount) {
                double profit =((alreadyReturnCoin - loandedCoinAmount) * awaitingPrice) - moneyForOperation;
                this.account.deposit(profit);
                return true;
            }
        } else if (awaitingPrice < generatingCryptoPrice.getActualCoinPrice(crypto)) {
            if (this.account.getBalance() >= amount * leverage) {
                this.account.withdrawal(amount * leverage);
            } else {
                // ak nema tolko peniaze aby vratil co pozicial tak sa zobereme jemu vsetko co ma
                this.account.withdrawal(this.account.getBalance());
            }
            return false;
        }
        return false;
    }
}

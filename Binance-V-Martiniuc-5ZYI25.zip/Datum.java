public class Datum {
    /**
     * Write a description of class Day here.
     * The class is responsible for the time period, where days, months and years are created for further use
     *
     * @author (Vitalii Martiniuc)
     * @version (6.01.2022)
     */

    //atributs
    private int day;
    private int month;
    private int year;


    public Datum(int day, int month, int year) {
       this.setDay(day);
       this.setMonth(month);
       this.setYear(year);

    }


    // show us if year is leap or not
    public boolean isLeapYear() {
        return ((((this.year % 4) == 0) && ((this.year % 100) != 0)) || ((this.year % 400) == 0));
    }

    // number of days
    private int giveTheNumberOfDaysInTheMonth() {
        switch (this.month) {
            case 2:
                if (this.isLeapYear()) {
                    return 29;
                } else {
                    return 28;
                }

            case 4:
            case 6:
            case 9:
            case 11:
                return 30;

            default:
                return 31;
        }
    }

    // show us the datum we choose
    public void list() {
        System.out.println(this.day + "." + this.month + "." + this.year);
    }
    public int getDay() {
        return this.day;
    }
    public int getMonth() {
        return this.month;
    }
    // show us the year
    public int getYear() {
        return this.year;
    }
    public void setDay(int newDay) {
        if (newDay < 1 || newDay > this.giveTheNumberOfDaysInTheMonth()) {
            this.day = 1;
        } else {
            this.day = newDay;
        }

    }
    public void setMonth(int month) {
        if (month > 0 && month <= 12) {
            this.month = month;
        } else {
            this.month = 1;
        }
    }
    public void setYear(int year) {
        if (year >= 1900) {
            this.year = year;
        } else {
            this.year = 1900;
        }
    }

    public void setDate(int dayNumber, int monthNumber, int yearNumber){
        this.setDay(dayNumber);
        this.setMonth(monthNumber);
        this.setYear(yearNumber);
    }


    public int nextDay() {
        this.setDay(this.day + 1);
        return  this.day;
    }
    public int nextMonth() {
        this.setMonth(this.month + 1);
        return this.month;
    }

    public int nextYear() {
       this.setYear(this.year + 1);
        return this.year;
    }

    public int addDays(int days) {
        this.day += days;
        while(this.day > this.giveTheNumberOfDaysInTheMonth()) {
            int temp = this.day - this.giveTheNumberOfDaysInTheMonth();
            this.day = temp;
            this.nextMonth();

        }
        return this.day;
    }
}


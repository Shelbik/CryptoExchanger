import java.util.Random;
import java.util.Scanner;

public class PasswordControl{
    private Account account;
    private String password;


    public PasswordControl(Account account) {

        this.account = account;
        this.password = account.getPassword();

    }


    /**
     * show us our password
     *
     * @return String
     */
    public String getPassword() {
        return this.password;
    }

    /**
     * set new Password
     *
     * @return String
     */
    public String setNewPassword(String newPassword) {
        this.password = newPassword;
        return this.password;
    }

    /**
     * check if password is correct
     *
     * @return boolean
     */
    public boolean checkPassword(String password) {
        return (this.password.equals(password));
    }


    /**
     * write captcha
     *
     * @return boolean
     */
    public boolean checkSupportElement() {
        Scanner scanner = new Scanner(System.in);;
        Random generator;

        generator = new Random();
        int captcha = generator.nextInt(10000);


        System.out.println("Rewrite " + captcha);
        int rewrite = scanner.nextInt();
        System.out.println("You wrote " + rewrite);

        return (captcha == rewrite);
    }

    /**
     * check correct password with captcha
     *
     * @return boolean
     */
    public boolean checkSecuirityElement(String password) {
        return (this.checkPassword(password) && this.checkSupportElement());
    }
}


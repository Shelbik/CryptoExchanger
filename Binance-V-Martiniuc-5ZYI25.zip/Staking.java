import java.util.ArrayList;

public class Staking {

    private ArrayList<Double> stakedCoinsAmountArray = new ArrayList<>();
    private ArrayList<Crypto> stakedCoinsNameArray = new ArrayList<>();
    private ArrayList<Double> stakedPercentArray = new ArrayList<>();
    private Datum datum;
    private Datum secondDatum;


    private ExchangerInterface exchangerInterface;
    private double bonusCoinsAmountByStaking = 0;


    public Staking(ExchangerInterface exchangerInterface, Datum datum) {
        this.datum = datum;

        this.secondDatum = new Datum(this.datum.getDay(), this.datum.getMonth(), this.datum.getYear());

        this.exchangerInterface = exchangerInterface;
    }

    public void infoAboutStaking() {
        System.out.println("Hello, on our exchange make a staking for the next number of days : 30, 60, 90, 120");
        System.out.println("Another days are not available for staking.");
    }

    public boolean stakeCoin(Crypto coin, StakingDays daysNumberForStake, double coinsAmount) {
        return this.stakingCoinProcess(coin, daysNumberForStake, coinsAmount);
    }

    public boolean addBonusCoinsAfterStakingToWallet(Crypto crypto, StakingDays stakingDays) {
        this.secondDatum.addDays(stakingDays.getDaysNumber(stakingDays));
        if (this.datum.getDay() == this.secondDatum.getDay() && (this.datum.getMonth() == this.secondDatum.getMonth()) && (this.datum.getYear() == this.secondDatum.getYear())) {
            addCoinToArray(exchangerInterface.getCoinIndexInArray(crypto), bonusCoinsAmountByStaking);
            return true;
        }
        return false;
    }

    public ArrayList<Double> getStakedCoinsAmountArray() {
        return stakedCoinsAmountArray;
    }

    public ArrayList<Crypto> getStakedCoinsNameArray() {
        return stakedCoinsNameArray;
    }

    public ArrayList<Double> getStakedPercentArray() {
        return stakedPercentArray;
    }


    public void getAllInfoAboutStakedCoinsInfo() {
        for (int i = 0; i < stakedCoinsNameArray.size(); i++) {
            System.out.println("Coin " + stakedCoinsNameArray.get(i) + " is staked in amount "
                    + stakedCoinsAmountArray.get(i) + " in " + stakedPercentArray.get(i) + "% for "
                    + getDaysFromPercent(stakedPercentArray.get(i)) + " days.");
        }
    }

    private int getDaysFromPercent(double percent) {
        switch ((int) percent) {
            case 5:
                return 30;
            case 10:
                return 60;
            case 15:
                return 90;
            case 20:
                return 120;
            default:
                return 0;
        }
    }

    private boolean checkCoinsAmount(double amount, int index) {
        return amount <= exchangerInterface.getEachCoinsAmountByArray().get(index);
    }


    private boolean removeCoinFromArray(double amount, int index) {
        double amountCoinsOnThisIndex = exchangerInterface.getEachCoinsAmountByArray().get(index); // ищём в базе множества коинов то самое количество БИТКА К ПРИМЕРУ которое хотим застейкать

        if (amount <= amountCoinsOnThisIndex) {
            double remainingCoinsAmountAfterStaking = amountCoinsOnThisIndex - amount; // сколько останеться после того как заберу монеты
            exchangerInterface.getEachCoinsAmountByArray().set(index, remainingCoinsAmountAfterStaking); // пока стейкается меняем коины на то количество которое осталось после стейка
            return true;
        } else {
            return false;
        }

    }


    private double addCoinToArray(int index, double bonusByStaking) {
        double previousAmountOfCoins = exchangerInterface.getEachCoinsAmountByArray().get(index); // ищём в базе множества коинов то самое количество БИТКА К ПРИМЕРУ которое хотим застейкать
        double futureCoinsAmountAfterStaking = previousAmountOfCoins + bonusByStaking;

        removeIndexFromAllArraysForStaking(index);

        return exchangerInterface.getEachCoinsAmountByArray().set(index, futureCoinsAmountAfterStaking);

    }

    private void removeIndexFromAllArraysForStaking(int index) {
        getStakedCoinsNameArray().remove(index);
        getStakedCoinsAmountArray().remove(index);
        getStakedPercentArray().remove(index);

    }

    private boolean stakingCoinProcess(Crypto coinToStake, StakingDays daysNumberForStake, double coinsAmount) {
        double percentFromStakingDays = daysNumberForStake.getPercent(daysNumberForStake);
        this.bonusCoinsAmountByStaking = coinsAmount / percentFromStakingDays;
        this.stakedPercentArray.add(percentFromStakingDays);


        if (checkCoinsAmount(coinsAmount, exchangerInterface.getCoinIndexInArray(coinToStake))) {
            stakedCoinsNameArray.add(coinToStake);
            stakedCoinsAmountArray.add(coinsAmount);
            removeCoinFromArray(coinsAmount, exchangerInterface.getCoinIndexInArray(coinToStake));
            return true;

        } else {
            return false;
        }
    }


}









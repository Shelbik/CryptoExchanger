


public class Account {
    private String password;
    private int accNumber;
    private double balance = 0;
    private Person person;
    private  PasswordControl ps;

    private static int grow;

    private final int accountNumber;


    public Account(Person person, String password) {
        this.person = person;
        this.password = password;
        grow++;
        this.accountNumber = getGrow();

        if (this.person.isAdult()) {
            System.out.println("Welcome to crypto World");

        }

    }

    public static int getGrow() {
        return grow;
    }

    public int getAccountsNumber() {
        return this.accNumber;
    }

    public String getPassword() {
        return this.password;
    }

    public void setNewPassword(String password) {
        this.ps.setNewPassword(password);
    }
    public double getBalance() {
        return this.balance;
    }
    public boolean deposit(double money) {
        if (money > 0) {
            this.balance += money;
            return true;
        } else {
            return false;

        }
    }
    public boolean withdrawal(double money) {
        if (money <= balance) {
            this.balance -= money;
            return true;
        } else {
            return false;

        }
    }

}




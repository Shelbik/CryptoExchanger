import java.util.*;

public class GeneratingCryptoPrice {

    private Datum datum;
    private Crypto[] coinsArray;
    private ArrayList <Double> coinsPrice = new ArrayList<>();

    public GeneratingCryptoPrice(Datum datum) {
        this.datum = datum;

        this.coinsArray = Crypto.values();
        generateArraysForPriceAndCoins();
    }

    private void generateArraysForPriceAndCoins() {
        for (Crypto crypto : coinsArray) {
            coinsPrice.add(crypto.getDefaultCryptoCoinPrice(crypto));
        }
    }

    public void generateNewPrice() {
        this.datum.nextDay();

        Random randomNumber = new Random();
        double randomPercentForNewPrice = randomNumber.nextInt(50);
        int priceUpOrDown = randomNumber.nextInt(2);
        randomPercentForNewPrice /= 100;

        boolean priceGoUp = false;

        if (priceUpOrDown == 1) {
            priceGoUp = true;
        } else {
            priceGoUp = false;
        }



        if (priceGoUp) {
            for (int indexInArray = 0; indexInArray < coinsPrice.size(); indexInArray++) {
                double oldPrice = (double) coinsPrice.get(indexInArray);
                double newPrice = oldPrice + (oldPrice * randomPercentForNewPrice);
                coinsPrice.set(indexInArray, newPrice);
            }

        } else {

            for (int indexInArray = 0; indexInArray < coinsPrice.size(); indexInArray++) {
                double oldPrice = (double) coinsPrice.get(indexInArray);
                double newPrice = oldPrice - (oldPrice * randomPercentForNewPrice);
                coinsPrice.set(indexInArray, newPrice);

            }
        }
    }


    public void showActualPrice() {
        for (int index = 0; index < coinsArray.length; index++) {
            System.out.println("For coin " + coinsArray[index] + " is current price " + coinsPrice.get(index) + "$");
        }
    }

    public double getActualCoinPrice(Crypto crypto) {
        for (int index = 0; index < this.coinsArray.length; index++) {
            if (this.coinsArray[index] == crypto) {
                //System.out.println("Current price for " + crypto + " is " + this.coinsPrice.get(index));
                return this.coinsPrice.get(index);
            }
        }
        return 0;
    }
}

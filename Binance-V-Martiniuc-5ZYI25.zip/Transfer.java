public class Transfer {
    private ExchangerInterface sourceAccount;

    public Transfer(ExchangerInterface sourceAaccount) {
        this.sourceAccount = sourceAccount;
    }

    public boolean transferCoin(ExchangerInterface destinationAccount, Crypto coin, double amount) {

        if(sourceAccount.getAmountOfCoin(coin) < amount) {
            return false;
        }

        if (amount <= sourceAccount.getAmountOfCoin(coin)) {
            double previousAmount = sourceAccount.getAmountOfCoin(coin);
            double newAmount = previousAmount - amount;
            sourceAccount.getEachCoinsAmountByArray().set(sourceAccount.getCoinIndexInArray(coin), newAmount);


            if (destinationAccount.getEachCoinYouHaveByArray().contains(coin)) {
                int index = destinationAccount.getCoinIndexInArray(coin);
                double beforeTransfer = destinationAccount.getAmountOfCoin(coin);
               double afterTransfer = beforeTransfer + amount;
                destinationAccount.getEachCoinsAmountByArray().set(index,afterTransfer);
            } else {

                destinationAccount.getEachCoinYouHaveByArray().add(coin);
                int index = destinationAccount.getCoinIndexInArray(coin);
                destinationAccount.getEachCoinsAmountByArray().add(index,amount);

            }
        }
        return true;
    }

    public boolean transferCoinByAccountNumber(int numberOfAccount, Crypto coin, double amount) {

        if(sourceAccount.getAmountOfCoin(coin) < amount ) {
            return false;
        }

        if (amount <= sourceAccount.getAmountOfCoin(coin)) {
            double previousAmount = sourceAccount.getAmountOfCoin(coin);
            double newAmount = previousAmount - amount;
            sourceAccount.getEachCoinsAmountByArray().set(sourceAccount.getCoinIndexInArray(coin), newAmount);


            if (destinationAccount.getEachCoinYouHaveByArray().contains(coin)) {
                int index = destinationAccount.getCoinIndexInArray(coin);
                double beforeTransfer = destinationAccount.getAmountOfCoin(coin);
                double afterTransfer = beforeTransfer + amount;
                destinationAccount.getEachCoinsAmountByArray().set(index,afterTransfer);
            } else {

                destinationAccount.getEachCoinYouHaveByArray().add(coin);
                int index = destinationAccount.getCoinIndexInArray(coin);
                destinationAccount.getEachCoinsAmountByArray().add(index,amount);

            }
        }
        return true;
    }
}

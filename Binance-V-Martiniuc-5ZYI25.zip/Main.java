
import java.util.Scanner;


public class Main {
    private static Scanner scanner = new Scanner(System.in);
    private static Person person;
    private static Account account;

    private static PasswordControl passwordControl;

    private static AccountNumbers accountNumbers;

    private static Staking staking;

    private static ExchangerInterface exchangerInterface;

    private static Datum date;

    private static StakingDays stakingDays;

    private static Transfer transfer;

    private static Crypto crypto;

    private static TradePosition tradePosition;

    private static GeneratingCryptoPrice generatingCryptoPrice;


    public static void main(String[] args) {
        System.out.println("Welcome to Binance Application");
        System.out.println("Lets make your account at our crypto market");
        System.out.println("Enter your first name please");
        String firstName = scanner.nextLine();
        System.out.println("Enter your second name please");
        String secondName = scanner.nextLine();
        System.out.println("Enter day number of your birth please");
        int dayOfBirth = scanner.nextInt();
        scanner.nextLine();
        System.out.println("Enter month number of your birth please");
        int mountOfBirth = scanner.nextInt();
        scanner.nextLine();
        System.out.println("Enter year number of your birth please");
        int yearOfBirth = scanner.nextInt();
        scanner.nextLine();
        System.out.println("Enter current year please");
        int currentYear = scanner.nextInt();
        scanner.nextLine();
        person = new Person(firstName, secondName, dayOfBirth, mountOfBirth, yearOfBirth, currentYear);
        // ****************************************** 2 **************************************************
        System.out.println("Now lets create your account at our market");
        System.out.println("Create the password");
        String password = scanner.nextLine();
        account = new Account(person, password);
        passwordControl = new PasswordControl(account);
        accountNumbers = new AccountNumbers();
        exchangerInterface = new ExchangerInterface(account);
        date = new Datum(27, 11, 2022);
        staking = new Staking(exchangerInterface, date);
        generatingCryptoPrice = new GeneratingCryptoPrice(date);
        transfer = new Transfer(exchangerInterface);
        tradePosition = new TradePosition(account, date);

        showOptions();


    }

    private static void showOptions() {
        Scanner scanner = new Scanner(System.in);

        System.out.println("To choose the option of our app, just write the number of option to the console.\n");
        System.out.println("Binance App Sections: ");
        System.out.println("1 - Person");
        System.out.println("2 - Account");
        System.out.println("3 - ExchangerInterface");
        System.out.println("4 - Staking");
        System.out.println("5 - Transfer");
        System.out.println("6 - Open Trade Position");
        System.out.println("6 - Check current coin`s price");
        System.out.println("8 - Information about Crypto Coins");
        System.out.println("9 - Date");
        System.out.println("0 - Exit the App");
        int sectionChoise = scanner.nextInt();
        scanner.nextLine();

        switch (sectionChoise) {
            case 1:
                showPersonOptions(person);
                break;
            case 2:
                showAccountOptions(account);
                break;
            case 3:
                showExchangerInterfaceOptions(exchangerInterface);
                break;
            case 0:
                System.out.println("See you next time");
                scanner.close();
                break;
        }

    }


    private static void showPersonOptions(Person person) {
        System.out.println("Welcome to Person Menu");
        System.out.println("Press number on your keybord to choose the option");
        System.out.println("1 - get First Name");
        System.out.println("2 - set First Name ");
        System.out.println("3 - get Second Name");
        System.out.println("4 - set Second Name ");
        System.out.println("5 - get Age");
        System.out.println("6 - check if you are Adult");
        System.out.println("0 - back to main menu");
        Scanner scanner = new Scanner(System.in);
        int option = scanner.nextInt();
        scanner.nextLine();
        switch (option) {
            case 1:
                person.getFirstName();
                showOptions();
                break;
            case 2:
                System.out.println("Enter your new first name");
                person.setFirstName(scanner.nextLine());
                showOptions();
                break;
            case 3:
                person.getSecondName();
                showOptions();
                break;
            case 4:
                System.out.println("Enter your new second name");
                person.setSecondName(scanner.nextLine());
                showOptions();
                break;
            case 5:
                System.out.println(person.getAge());
                showOptions();
                break;
            case 6:
                System.out.println(person.isAdult());
                showOptions();
                break;
            case 0:
                showOptions();
            default:
                System.out.println("Your option doesnt exist");
                System.out.println("Choose one more time");
                option = scanner.nextInt();
                scanner.nextLine();
                break;
        }


    }

    private static void showAccountOptions(Account account) {
        System.out.println("Welcome to Account Menu");
        System.out.println("Press number on your keybord to choose the option");
        System.out.println("1 - get Account Number");
        System.out.println("2 - get Password");
        System.out.println("3 - get Balance");
        System.out.println("4 - deposit");
        System.out.println("5 - withdrawal");
        System.out.println("0 - back to main menu");
        Scanner scanner = new Scanner(System.in);
        int option = scanner.nextInt();
        switch (option) {
            case 1:
                account.getAccountsNumber();
                break;
            case 2:
                account.getPassword();
                break;
            case 3:
                account.getBalance();
                break;
            case 4:
                System.out.println("Enter amount you want to deposit");
                account.deposit(scanner.nextInt());
                scanner.nextLine();
                break;
            case 5:
                System.out.println("Enter amount you want to withdrawal");
                account.withdrawal(scanner.nextInt());
                scanner.nextLine();
                break;
            case 0:
                showOptions();
            default:
                System.out.println("Your option doesnt exist");
                System.out.println("Choose one more time");
                option = scanner.nextInt();
                scanner.nextLine();
                break;
        }
    }

    private static void showExchangerInterfaceOptions(ExchangerInterface exchangerInterface) {
        System.out.println("Welcome to (Exchanger Interface Menu");
        System.out.println("Press number on your keybord to choose the option");
        System.out.println("1 - buy Coin");
        System.out.println("2 - sell Coin");
        System.out.println("3 - get info about Coins");
        System.out.println("4 - see list of your coins");
        System.out.println("5 - see list of your coins amount");
        System.out.println("0 - back to main menu");

        Scanner scanner = new Scanner(System.in);
        int option = scanner.nextInt();
        switch (option) {
            case 1:
                System.out.println("At our exchanger you can buy these coins: ");
                showCryptoCoinIndexs();

                System.out.println("Type the money amount you want to spend");
                int money = scanner.nextInt();
                scanner.nextLine();
                System.out.println("Choose index of crypto coin");
                int indexForBuying = scanner.nextInt();
                scanner.nextLine();
                exchangerInterface.buyCoin(money, crypto.getCryptoCoin(indexForBuying));
                break;
            case 2:
                System.out.println("Type the coin`s amount you want to sell");
                double coinAmount = scanner.nextInt();
                scanner.nextLine();
                System.out.println("Choose index of crypto coin");
                int indexForSelling = scanner.nextInt();
                scanner.nextLine();
                exchangerInterface.sellCoin(coinAmount, crypto.getCryptoCoin(indexForSelling));
                break;
            case 3:
                exchangerInterface.getCoinsInfo();
                break;
            case 4:
                exchangerInterface.getEachCoinYouHaveByArray();
                break;
            case 5:
                exchangerInterface.getEachCoinsAmountByArray();
                break;
            case 0:
                showOptions();
            default:
                System.out.println("Your option doesnt exist");
                System.out.println("Choose one more time");
                option = scanner.nextInt();
                scanner.nextLine();
                break;
        }

    }

    private static void showTransferOptions(ExchangerInterface exchangerInterface) {
        System.out.println("Welcome to Person Menu");
        System.out.println("Press number on your keybord to choose the option");
        System.out.println("1 - transfer Coin");
        System.out.println("0 - back to main menu");
        Scanner scanner = new Scanner(System.in);
        int option = scanner.nextInt();
        scanner.nextLine();
        switch (option) {
            case 1:
                System.out.println("Enter CryptoCoin index you want to send");
                showCryptoCoinIndexs();
                int coinIndex = scanner.nextInt();
                scanner.nextLine();
                System.out.println("Enter amount you want to send");
                int coinAmountToTrasnfer = scanner.nextInt();
                scanner.nextLine();



                transfer.transferCoin(ExchangerInterface distinationAccount,crypto.getCryptoCoin(coinIndex),coinAmountToTrasnfer);
        }
    }

    private static void showCryptoCoinIndexs() {
        System.out.println("Index 1 - BTC");
        System.out.println("Index 2 - ETH");
        System.out.println("Index 2 - SOL");
        System.out.println("Index 2 - APE");
        System.out.println("Index 2 - SAND");
        System.out.println("Index 2 - ATOM");
        System.out.println("Index 2 - BNB");
        System.out.println("***************************");
    }
}

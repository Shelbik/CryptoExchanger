
import java.util.ArrayList;

public class ExchangerInterface {
    private Account account;

    private ArrayList<Crypto> cryptoBase = new ArrayList<>();
    private ArrayList<Double> fullCoinsAmount = new ArrayList<>();

    public ExchangerInterface(Account account) {

        this.account = account;

    }

    public boolean buyCoin(double money, Crypto cryptoCoin) {
        return this.buyingCoinProcess(money,cryptoCoin);
    }

    public boolean sellCoin(double coinsAmount, Crypto cryptoCoin) {
        return this.sellingCoinProcess(coinsAmount,cryptoCoin);
    }


    public void getCoinsInfo() {
        for (int coinIndex = 0; coinIndex < this.cryptoBase.size(); coinIndex++) {
            System.out.println("Coin " +  this.cryptoBase.get(coinIndex) + " is in amount " +  this.fullCoinsAmount.get(coinIndex));
        }
    }

    public ArrayList<Crypto> getEachCoinYouHaveByArray() {
        return this.cryptoBase;
    }

    public ArrayList<Double> getEachCoinsAmountByArray() {
        return  this.fullCoinsAmount;
    }


    public int getCoinIndexInArray(Crypto coin) {
        return getEachCoinYouHaveByArray().indexOf(coin);

    }

    public double getAmountOfCoin(Crypto coin) {
        return this.fullCoinsAmount.get(getCoinIndexInArray(coin));
    }

    private boolean buyingCoinProcess(double money, Crypto coin) {
        double coinAmount = money / coin.getDefaultCryptoCoinPrice(coin);
        if (money > this.account.getBalance()) {
            return false;

        } else {

            if (this.cryptoBase.contains(coin)) {
                double currentCoinAmountAtAccount = this.fullCoinsAmount.get(this.cryptoBase.indexOf(coin));  // plus amount of coints on cryptocoin index
                currentCoinAmountAtAccount += coinAmount;
                account.withdrawal(money);
                this.fullCoinsAmount.set(this.cryptoBase.indexOf(coin), currentCoinAmountAtAccount);


            } else {
                this.cryptoBase.add(coin);
                this.fullCoinsAmount.add(coinAmount);
                this.account.withdrawal(money);
            }
        }
        return true;
    }

    private boolean sellingCoinProcess(double coinsAmount, Crypto cryptoCoin) {
        int amountOfCoinToSell =  this.cryptoBase.indexOf(cryptoCoin); // temp2 = index of cryptocoin in array to find place in fullCoinsAray

        if (coinsAmount <= fullCoinsAmount.get(amountOfCoinToSell)) {
            double moneyAfterSaleCoin = coinsAmount * cryptoCoin.getDefaultCryptoCoinPrice(cryptoCoin);
            double currentCoinAmount = fullCoinsAmount.get(amountOfCoinToSell);  // plus amount of coints on cryptocoin index

            currentCoinAmount -= coinsAmount;
            this.fullCoinsAmount.set(amountOfCoinToSell, currentCoinAmount); // меняем в листе колво монет на количество оставшиеся после продажи
            this. account.deposit(moneyAfterSaleCoin); // добавляем на баланс деньги от продажи монет
            return true;

        } else {
            return false;
        }
    }

}


